#define LLVM_REVISION "631cd8006dc9f924fd94cb3b3f2f1f2e2e06f639"
#define LLVM_REPOSITORY "https://github.com/DeNA/DeClang.git"
